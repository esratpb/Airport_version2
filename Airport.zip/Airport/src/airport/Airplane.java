package airport;

public class Airplane {
    private  String planeId;
    private int maxNumberOfPassenger;
    private int currentNumberOfPassengers;
    private boolean isCurrentlyFlying;
    private double speed;

    public int loadPassenger(int numberOfPassenger){
        this.currentNumberOfPassengers+=numberOfPassenger;
        return this.currentNumberOfPassengers;
    }

    public void unloadPassenger(){
        this.currentNumberOfPassengers=0;
    }
    

    //Getter Setter constructor

    public Airplane(String planeId, int maxNumberOfPassenger, int currentNumberOfPassengers, boolean isCurrentlyFlying, double speed) {
        this.planeId = planeId;
        this.maxNumberOfPassenger = maxNumberOfPassenger;
        this.currentNumberOfPassengers = currentNumberOfPassengers;
        this.isCurrentlyFlying = isCurrentlyFlying;
        this.speed = speed;
    }

    public String getPlaneId() {return planeId;}

    public void setPlaneId(String planeId) {this.planeId = planeId;}

    public int getMaxNumberOfPassenger() {return maxNumberOfPassenger;}

    public void setMaxNumberOfPassenger(int maxNumberOfPassenger) {this.maxNumberOfPassenger = maxNumberOfPassenger;}

    public int getCurrentNumberOfPassengers() {return currentNumberOfPassengers;}

    public void setCurrentNumberOfPassengers(int currentNumberOfPassengers) {this.currentNumberOfPassengers = currentNumberOfPassengers;}

    public boolean isCurrentlyFlying() {return isCurrentlyFlying;}

    public void setCurrentlyFlying(boolean currentlyFlying) {isCurrentlyFlying = currentlyFlying;}

    public double getSpeed() {return speed;}

    public void setSpeed(double speed) {this.speed = speed;}


}
